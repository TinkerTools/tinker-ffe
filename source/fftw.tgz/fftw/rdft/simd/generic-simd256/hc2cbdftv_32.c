/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-generic256.h"
#include "../common/hc2cbdftv_32.c"
